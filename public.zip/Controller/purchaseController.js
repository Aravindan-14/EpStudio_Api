import { promisePool as db } from "../config/db.js";
import nodemailer from "nodemailer"


//Create Purchase api start
export const createPurchase = (req, res) => {

function sendMail(data,image){

  var msgBody = "<h1>Customer details </h1><br>";
  for(let k in data){
   msgBody += k + " : " + data[k] +"<br>"
  }

  var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'eyampoosu@gmail.com',
      pass: 'etayeeapttxdbaxz'
    }
  });
  
  var mailOptions = {
    from: 'eyampoosu@gmail.com',
    to: 'aravindan2518@gmail.com',
    subject: 'New Order Recived...!',
    html:msgBody ,
    attachments : [
      { // use URL as an attachment
        filename: image.originalname,
        path: image.path
      }
    ]

    
  };
  
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + mailOptions.to);
      res.send({status:"mail sent"})
    }
  });
}

const {
  customer_Name,
  email,
  phone_No,
  address,
  product_Name,
  quantity,
  price,
}=req.body;

const image=req.file
let value=[customer_Name,email,phone_No,address,product_Name,quantity,price,image.filename]

sendMail(req.body,image)
const sql =
"INSERT INTO customer (`customer_Name`,`email`,`phone_No`,`address`,`product_Name`,`quantity`,`price`,`image`) VALUES (?)";
  db.query(sql, [value], (err, result) => {
    if (err) return res.send(err);
    console.log("Number of records inserted: " + result.affectedRows);
    return res.send("succes");
  });

};
